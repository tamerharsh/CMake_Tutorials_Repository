
#pragma once
#ifndef FOOBAR_FOO_H
#define FOOBAR_FOO_H

#include <foo/config.h>

void foo(void);

#endif
